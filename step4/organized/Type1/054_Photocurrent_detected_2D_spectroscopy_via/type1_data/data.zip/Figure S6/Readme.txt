This folder contains the data for Figure S6.

The acusto-optic correction factors for t2 = 30 fs for all pulse trains are provided as "correction_factors_rf_0,05.txt" and "correction_factors_rf_0,2.txt" for RF powers of 0.05 and 0.2, respectively. Both correction factors are plotted against the pulse train number ("pulse_train_numbers.txt").