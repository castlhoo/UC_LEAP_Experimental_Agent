This folder contains the uncorrected rephasing time-domain map and 2D spectrum of the laser at an RF power of 0.2 (as shown in Fig. S7d in the SI) in .txt format.

"Laser_0,2_uncorr_rephasing_td_scaled_1x.txt" contains the real part of the uncorrected rephasing time-domain map for a t2 delay of 30 fs measured at an RF power of 0.2. 

"Laser_0,2_uncorr_rephasing_fd_scaled_1x.txt" contains the real part of the uncorrected rephasing 2D spectrum for a t2 delay of 30 fs measured at an RF power of 0.2. 

The time-domain map is plotted against the t1 delays and t3 delays, which are given as "t1_delay.txt" and "t3_delay.txt", respectively, in units of femtoseconds.
The 2D spectrum is plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.