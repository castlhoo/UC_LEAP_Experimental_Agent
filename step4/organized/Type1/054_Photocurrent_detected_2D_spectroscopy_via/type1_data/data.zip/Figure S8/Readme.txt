This folder contains the data of Figure S8, provided in .txt format. The respective Matlab scripts for the individual figure panels ("simulate_artifact_Fig_...") are also provided. Note that the Matlab scripts require "pc_weights_calculator.m" and "DarkBluetoRedContour.mat" to be in the same folder.

The complex-valued 2D time-domain maps of the individual figure panels are given by the files
- FigS8a_rephasing_signal.txt
- FigS8a_nonrephasing_signal.txt
- FigS8b_rephasing_signal.txt
- FigS8b_nonrephasing_signal.txt
- FigS8c_rephasing_signal.txt
- FigS8c_nonrephasing_signal.txt

The time-domain maps listed above are also provided in .mat format.

All 2D time-domain maps are plotted over the time-delay axes "t1_delay.txt" and "t3_delay.txt", with time-delay values given in units of femtoseconds.