clear;
close all;

% create spectrum
c = 2.998E8; % speed of light [m/s]
lambda0 = 825E-9; % wavelength [m]
w0 = 2*pi*c/lambda0*1E-15; % central frequency [rad/fs]
delta_lambda = 50E-9; % bandwidth [m]

sigma = w0/lambda0*delta_lambda; % bandwidth [rad/fs]
pulse_duration = (0.44.*2.*pi)./sigma % pulse duration [fs]

w = linspace(1,4,1000); % frequency axis [rad/fs]
gauss = exp(-((w - w0).^2)/(2*sigma^2));
phase = zeros(1,length(w));
A = gauss.*exp(1j*phase);

t1 = linspace(-91,91,27); % from -91 to 91 fs in 27 steps
t3 = linspace(-91,91,27); % from -91 to 91 fs in 27 steps
t2 = 0; %[fs]

t_0 = 0; % [fs]

gamma0 = 0.1129; % rotating frame parameter
rephasing = [-1 1 1 -1]; % phase coefficients of rephasing signal
nonrephasing = [1 -1 1 -1]; % phase coefficients of nonrephasing signal
phase_cycling_scheme = [1 3 3 3];


%% artifact: introduce nonlinearity

% artifact strengths
alpha = 1;  % scaling factor of quadratic field term
beta = 0.5; % scaling factor of cubic field term
gamma = 0;  % scaling factor of fourth-order field term

% normalize time domain maps
normalize = false;

% phase cycling
[phi_R weights_R] = pc_weights_calculator(rephasing,phase_cycling_scheme);
[phi_NR weights_NR] = pc_weights_calculator(nonrephasing,phase_cycling_scheme);

APD_signal_R=zeros(length(t3),length(t1),length(phi_R));
APD_signal_NR=zeros(length(t3),length(t1),length(phi_NR));


%% Calculate rephasing and nonrephasing signals
A = A / max(abs(A));

for ii=1:length(phi_R)
    for jj=1:length(t3)
        for kk=1:length(t1)
            APD_spec_R = (A.*exp(-1i*(phi_R(ii,1)+(w-w0*(1-gamma0))*0))+ ...
                A.*exp(-1i*(phi_R(ii,2)+(w-w0*(1-gamma0))*t1(kk)))+ ...
                A.*exp(-1i*(phi_R(ii,3)+(w-w0*(1-gamma0))*(t1(kk)+t2)))+ ...
                A.*exp(-1i*(phi_R(ii,4)+(w-w0*(1-gamma0))*(t1(kk)+t2+t3(jj)))));

            APD_spec_NR = (A.*exp(-1i*(phi_NR(ii,1)+(w-w0*(1-gamma0))*0))+ ...
                A.*exp(-1i*(phi_NR(ii,2)+(w-w0*(1-gamma0))*t1(kk)))+ ...
                A.*exp(-1i*(phi_NR(ii,3)+(w-w0*(1-gamma0))*(t1(kk)+t2)))+ ...
                A.*exp(-1i*(phi_NR(ii,4)+(w-w0*(1-gamma0))*(t1(kk)+t2+t3(jj)))));


            APD_spec_expanded_R = APD_spec_R + alpha.*APD_spec_R.^2 + beta.*APD_spec_R.^3 + gamma.*APD_spec_R.^4;
            APD_spec_expanded_NR = APD_spec_NR + alpha.*APD_spec_NR.^2 + beta.*APD_spec_NR.^3 + gamma.*APD_spec_NR.^4;

            %% Calculate APD signal => spectrally integrated signal
            APD_signal_R(jj,kk,ii) = -(sum((APD_spec_expanded_R.*conj(APD_spec_expanded_R))));
            APD_signal_NR(jj,kk,ii)= -(sum((APD_spec_expanded_NR.*conj(APD_spec_expanded_NR))));
        end
    end
end


%% Phase weighting
rephasing_TD = zeros(length(t3),length(t1));
nonrephasing_TD = zeros(length(t3),length(t1));

for ii=1:size(APD_signal_R,3)
    rephasing_TD = rephasing_TD + APD_signal_R(:,:,ii)*weights_R(ii);
    nonrephasing_TD = nonrephasing_TD + APD_signal_NR(:,:,ii)*weights_NR(ii);
end

% normalize
if normalize == true
    rephasing_TD = rephasing_TD./max(max(abs(rephasing_TD)));
    nonrephasing_TD = nonrephasing_TD./max(max(abs(nonrephasing_TD)));
end


%% Plotting
load("DarkBlueToRedContour.mat");
fs = 16; % font size;

%% Plot time domain data
figure(Position = [100 100 800 600])
tile1 = tiledlayout(1,2);

nexttile;
imagesc(t1,t3,real(rephasing_TD));
axis xy; axis square;
hold on
xlabel("t_1 delay (fs)");
ylabel("t_3 delay (fs)");
colormap(Dark_BluetoRed);
colorbar;
title("Rephasing","FontSize", fs);
clim = max(abs(caxis));
caxis([-clim, clim]);
set(gca,"FontSize",fs);
set(gca,'LineWidth',2);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'TickLength', [0.02 0.035])
hc = colorbar;
set(hc,'TickLength',0.03)
set(hc,'linewidth',1.5);
set(hc,'FontSize',fs);


nexttile;
imagesc(t1,t3,real(nonrephasing_TD));
axis xy; axis square;
hold on
axis xy;
xlabel("t_1 delay (fs)");
ylabel("t_3 delay (fs)");
colormap(Dark_BluetoRed);
colorbar;
title("Nonrephasing","FontSize", fs);
clim = max(abs(caxis));
caxis([-clim, clim]);
set(gca,"FontSize",fs);
set(gca,'LineWidth',2);
set(gca,'XMinorTick','on','YMinorTick','on');
set(gca,'TickLength', [0.02 0.035])
hc = colorbar;
set(hc,'TickLength',0.03)
set(hc,'linewidth',1.5);
set(hc,'FontSize',fs);

title(tile1, ['\alpha = ', num2str(alpha), ', \beta = ', num2str(beta)],"FontSize",fs);