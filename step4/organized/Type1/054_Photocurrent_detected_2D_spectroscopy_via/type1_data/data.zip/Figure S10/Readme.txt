This folder contains the corrected absorptive 2D spectra of light-harvesting complex II (LH2) measured at an RF power of 0.5 (as shown in Fig. S10 in the SI) in .txt format. 

"LH2_0,5_T2_0fs_R+NR_fd_corrected.txt" contains the corrected absorptive 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.5. The 2D spectrum has been scaled by a factor of 3.24.

"LH2_0,5_T2_500fs_R+NR_fd_corrected.txt" contains the corrected absorptive 2D spectrum for a t2 delay of 500 fs measured at an RF power of 0.5. The 2D spectrum has been scaled by a factor of 3.90.

The 2D spectra are plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.