This folder contains the data for Figure 4a in .txt format. 

The linear field autocorrelations for various normalized RF powers are contained in the following files:
- Laser_DazzlerPower_0,0005_td.txt
- Laser_DazzlerPower_0,005_td.txt
- Laser_DazzlerPower_0,05_td.txt
- Laser_DazzlerPower_0,5_td.txt
- Laser_DazzlerPower_1,0_td.txt
The number in the file name represents the normalized RF power. All autocorrelations are plotted over the time-delay values given in "time_delay.txt" in units of femtoseconds.