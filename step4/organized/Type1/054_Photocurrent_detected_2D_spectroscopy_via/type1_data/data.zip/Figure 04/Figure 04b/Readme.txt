This folder contains the data for Figure 4b in .txt format. 

The linear spectra for various normalized RF powers are contained in the following files:
- Laser_DazzlerPower_0,0005_spectrum.txt
- Laser_DazzlerPower_0,001_spectrum.txt
- Laser_DazzlerPower_0,002_spectrum.txt
- Laser_DazzlerPower_0,005_spectrum.txt
- Laser_DazzlerPower_0,007_spectrum.txt
- Laser_DazzlerPower_0,01_spectrum.txt
- Laser_DazzlerPower_0,02_spectrum.txt
- Laser_DazzlerPower_0,05_spectrum.txt
- Laser_DazzlerPower_0,1_spectrum.txt
- Laser_DazzlerPower_0,2_spectrum.txt
- Laser_DazzlerPower_0,5_spectrum.txt
- Laser_DazzlerPower_1,0_spectrum.txt

The number in the file name represents the normalized RF power. All spectra are plotted over the frequency axis given in "frequency_axis.txt" in units of inverse centimeters.