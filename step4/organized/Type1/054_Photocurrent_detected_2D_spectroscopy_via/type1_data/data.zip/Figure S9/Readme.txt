This folder contains the rephasing time-domain maps and absorptive 2D spectra of light-harvesting complex II (LH2) (as shown in Fig. S9 in the SI) in .txt format. 

"LH2_0,05_T2_0fs_rephasing_td_scaled_3.78x_uncorrected.txt" contains the real part of the uncorrected rephasing time-domain map for a t2 delay of 0 fs measured at an RF power of 0.05. The time-domain map has been scaled by a factor of 3.78.

"LH2_0,05_T2_0fs_R+NR_fd_scaled_4.4x_uncorrected.txt" contains the uncorrected absorptive 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 4.40.

"LH2_0,05_T2_0fs_rephasing_td_corrected.txt" contains the real part of the corrected rephasing time-domain map for a t2 delay of 0 fs measured at an RF power of 0.05. The time-domain map has been scaled by a factor of 5.68.

"LH2_0,05_T2_0fs_R+NR_fd_corrected.txt" contains the corrected absorptive 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 6.62.

"LH2_0,005_T2_0fs_rephasing_td_scaled_5.91x.txt" contains the real part of the rephasing time-domain map for a t2 delay of 0 fs measured at an RF power of 0.005. The time-domain map has been scaled by a factor of 5.91.

"LH2_0,005_T2_0fs_R+NR_fd_scaled_9.09x.txt" contains the absorptive 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.005. The 2D spectrum has been scaled by a factor of 9.09.

The time-domain maps are plotted against the t1 delays and t3 delays, which are given as "t1delays.txt" and "t3delays.txt", respectively, in units of femtoseconds.
The 2D spectra are plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.