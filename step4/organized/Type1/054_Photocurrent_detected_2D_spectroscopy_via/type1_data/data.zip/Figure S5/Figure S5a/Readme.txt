This folder contains the non-rephasing time-domain maps of light-harvesting complex II (LH2) for different RF powers (as shown in Fig. S5a in the SI) in .txt format. Note that the time-domain maps are scaled relative to the maximum signal amplitude of the rephasing time-domain map at t2 = 0 fs with an RF power of 0.5.

"DP_0,005_T2_0fs_non-rephasing_td_scaled_5.04x.txt" contains the real part of the non-rephasing time-domain map for a t2 delay of 0 fs measured at an RF power of 0.005. The time-domain map has been scaled by a factor of 5.04.

"DP_0,05_T2_0fs_non-rephasing_td_scaled_3.3x.txt" contains the real part of the non-rephasing time-domain map for a t2 delay of 0 fs measured at an RF power of 0.05. The time-domain map has been scaled by a factor of 3.30.

"DP_0,5_T2_0fs_non-rephasing_td_scaled_1.56x.txt" contains the real part of the non-rephasing time-domain map for a t2 delay of 0 fs measured at an RF power of 0.5. The time-domain map has been scaled by a factor of 1.56.

All time-domain maps are plotted against the t1 delays and t3 delays, which are given as "t1delays.txt" and "t3delays.txt", respectively, in units of femtoseconds.