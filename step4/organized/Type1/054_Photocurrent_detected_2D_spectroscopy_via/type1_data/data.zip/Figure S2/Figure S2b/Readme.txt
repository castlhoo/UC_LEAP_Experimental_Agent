This folder contains the non-rephasing 2D spectra of the laser for different RF powers (as shown in Fig. S2b in the SI) in .txt format. Note that the 2D spectra are scaled relative to the maximum signal amplitude of the rephasing 2D spectrum at t2 = 0 fs with an RF power of 0.5.

"DP_0,005_T2_0fs_non-rephasing_fd_scaled_77.41x.txt" contains the real part of the non-rephasing 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.005. The 2D spectrum has been scaled by a factor of 77.41.

"DP_0,05_T2_0fs_non-rephasing_fd_scaled_32.61x.txt" contains the real part of the non-rephasing 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 32.61.

"DP_0,5_T2_0fs_non-rephasing_fd_scaled_4.58x.txt" contains the real part of the non-rephasing 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.5. The 2D spectrum has been scaled by a factor of 4.58.

All 2D spectra are plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.