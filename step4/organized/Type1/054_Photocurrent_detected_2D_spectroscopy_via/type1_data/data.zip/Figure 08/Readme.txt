This folder contains the data for Figure 8 in .txt and .mat format. The Matlab script for the simulation of the time-domain maps ("simulate_artifact.m") is also provided. Note that the Matlab scripts require "pc_weights_calculator.m" and "DarkBluetoRedContour.mat" to be in the same folder.

"Fig8a_rephasing_signal.txt" and "Fig8a_rephasing_signal.mat" contain the complex-valued data of the rephasing time-domain map. 

"Fig8a_nonrephasing_signal.txt" and "Fig8a_nonrephasing_signal.mat" contain the complex-valued data of the nonrephasing time-domain map. 

All time-domain maps are plotted against the t1 delays and t3 delays, which are given as "t1_delay.txt" and "t3_delay.txt", respectively, in units of femtoseconds.