This folder contains the absorptive reference 2D spectrum of the squaraine dimer dSQAB3 at t2 = 30 fs and an RF power of 0.005 (as shown in Fig. 9b, left in the manuscript) in .txt format. The 2D spectrum is provided by the file "dSQAB3_0,005_absorptive_fd_scaled_9.32.txt". Note that the 2D spectrum is normalized relative to the maximum of the uncorrected 2D spectrum at RF = 0.2, thus it is scaled by a factor of 9.32. The 2D spectrum is plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.

This folder also contains the data of the anti-diagonal lineshape fits of the upper diagonal peaks of the 2D spectra for various RF powers and correction schemes (Fig. 9b, middle and right):
"fit_rf0,005.txt" contains the anti-diagonal lineshape fit at low RF Power (RF = 0.005). 
"fit_rf0,05_raw.txt" contains the anti-diagonal lineshape fit of the uncorrected 2D spectrum at RF = 0.05.
"fit_rf0,05_ampcorr.txt" contains the anti-diagonal lineshape fit of the amplitude-corrected 2D spectrum at RF = 0.05.
"fit_rf0,05_subcorr.txt" contains the anti-diagonal lineshape fit of the subtraction-corrected 2D spectrum at RF = 0.05.
"fit_rf0,2_raw.txt" contains the anti-diagonal lineshape fit of the uncorrected 2D spectrum at RF = 0.2.
"fit_rf0,2_ampcorr.txt" contains the anti-diagonal lineshape fit of the amplitude-corrected 2D spectrum at RF = 0.2.
"fit_rf0,2_subcorr.txt" contains the anti-diagonal lineshape fit of the subtraction-corrected 2D spectrum at RF = 0.2.
All fit curves are plotted against the frequency axis ("frequency_axis.txt") given in units of inverse centimeters.


