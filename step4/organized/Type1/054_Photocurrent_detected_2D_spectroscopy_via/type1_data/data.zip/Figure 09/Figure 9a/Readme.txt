This folder contains the absorptive 2D spectra of the squaraine dimer dSQAB3 at t2 = 30 fs acquired at various RF powers and with different correction schemes (as shown in Fig. 9a in the manuscript). Note that all 2D spectra are normalized relative to the maximum of the uncorrected 2D spectrum at RF = 0.2.

"dSQAB3_0,05_uncorr_absorptive_fd_scaled_1.83" contains the uncorrected absorptive 2D spectrum for a t2 delay of 30 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 1.83.

"dSQAB3_0,05_ampcorr_absorptive_fd_scaled_1.74" contains the amplitude-corrected absorptive 2D spectrum for a t2 delay of 30 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 1.74.

"dSQAB3_0,05_subcorr_absorptive_fd_scaled_1.90" contains the subtraction-corrected absorptive 2D spectrum for a t2 delay of 30 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 1.90.

"dSQAB3_0,2_uncorr_absorptive_fd" contains the uncorrected absorptive 2D spectrum for a t2 delay of 30 fs measured at an RF power of 0.2. 

"dSQAB3_0,2_ampcorr_absorptive_fd_scaled_1.08" contains the amplitude-corrected absorptive 2D spectrum for a t2 delay of 30 fs measured at an RF power of 0.2. The 2D spectrum has been scaled by a factor of 1.08.

"dSQAB3_0,2_subcorr_absorptive_fd_scaled_1.38" contains the subtraction-corrected absorptive 2D spectrum for a t2 delay of 30 fs measured at an RF power of 0.2. The 2D spectrum has been scaled by a factor of 1.38. 

All 2D spectra are plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.

