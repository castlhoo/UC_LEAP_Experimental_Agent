This folder contains the 2D spectra of light-harvesting complex II (LH2) acquired with a phase-modulation (PM) F-2DES setup (as shown in the left panels of the first and second rows in Fig. S11 in the SI) in .txt format.

"LH2_PM_T2_0fs_absorptive_fd.txt" contains the absorptive PM F-2DES spectrum for a t2 delay of 0 fs.

"LH2_PM_T2_500fs_absorptive_fd.txt" contains the absorptive PM F-2DES spectrum for a t2 delay of 500 fs.

All 2D spectra are plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.