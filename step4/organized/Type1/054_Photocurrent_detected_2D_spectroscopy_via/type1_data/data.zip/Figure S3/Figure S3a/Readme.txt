This folder contains the rephasing time-domain maps of the laser for different RF powers (as shown in Fig. S3a in the SI) in .txt format. Note that the time-domain maps are scaled relative to the maximum signal amplitude of the rephasing time-domain map at t2 = 0 fs with an RF power of 0.5.

"DP_0,005_T2_500fs_rephasing_td_scaled_22.81x.txt" contains the real part of the rephasing time-domain map for a t2 delay of 500 fs measured at an RF power of 0.005. The time-domain map has been scaled by a factor of 22.81.

"DP_0,05_T2_500fs_rephasing_td_scaled_9.05x.txt" contains the real part of the rephasing time-domain map for a t2 delay of 500 fs measured at an RF power of 0.05. The time-domain map has been scaled by a factor of 9.05.

"DP_0,5_T2_500fs_rephasing_td_scaled_1.06x.txt" contains the real part of the non-rephasing time-domain map for a t2 delay of 500 fs measured at an RF power of 0.5. The time-domain map has been scaled by a factor of 1.06.

All time-domain maps are plotted against the t1 delays and t3 delays, which are given as "t1delays.txt" and "t3delays.txt", respectively, in units of femtoseconds.