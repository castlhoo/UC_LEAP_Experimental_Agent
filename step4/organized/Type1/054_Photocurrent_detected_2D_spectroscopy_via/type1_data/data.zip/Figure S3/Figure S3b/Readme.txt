This folder contains the rephasing 2D spectra of the laser for different RF powers (as shown in Fig. S3b in the SI) in .txt format. Note that the 2D spectra are scaled relative to the maximum signal amplitude of the rephasing 2D spectrum at t2 = 0 fs with an RF power of 0.5.

"DP_0,005_T2_500fs_rephasing_fd_scaled_105.59x.txt" contains the real part of the rephasing 2D spectrum for a t2 delay of 500 fs measured at an RF power of 0.005. The 2D spectrum has been scaled by a factor of 105.59.

"DP_0,05_T2_500fs_rephasing_fd_scaled_15.03x.txt" contains the real part of the rephasing 2D spectrum for a t2 delay of 500 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 15.03.

"DP_0,5_T2_500fs_rephasing_fd_scaled_1.53x.txt" contains the real part of the rephasing 2D spectrum for a t2 delay of 500 fs measured at an RF power of 0.5. The 2D spectrum has been scaled by a factor of 1.53.

All 2D spectra are plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.