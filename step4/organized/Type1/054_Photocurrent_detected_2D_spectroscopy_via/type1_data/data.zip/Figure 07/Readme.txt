This folder contains the absorptive 2D spectra of light-harvesting complex II (LH2) for different RF powers at t2 = 0 fs and t2 = 500 fs (as shown in Fig. 7 in the manuscript) in .txt format. Note that the 2D spectra are scaled relative to the maximum signal amplitude of the 2D spectrum at t2 = 0 fs with an RF power of 0.5.

"DP_0,005_T2_0fs_R+NR_fd_scaled_9.09x.txt" contains the absorptive 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.005. The 2D spectrum has been scaled by a factor of 9.09.

"DP_0,05_T2_0fs_R+NR_fd_scaled_4.4x.txt" contains the absorptive 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 4.40.

"DP_0,5_T2_0fs_R+NR_fd_scaled_1x.txt" contains the absorptive 2D spectrum for a t2 delay of 0 fs measured at an RF power of 0.5. 


"DP_0,005_T2_500fs_R+NR_fd_scaled_16.72x.txt" contains the absorptive 2D spectrum for a t2 delay of 500 fs measured at an RF power of 0.005. The 2D spectrum has been scaled by a factor of 16.72.

"DP_0,05_T2_500fs_R+NR_fd_scaled_7.36x.txt" contains the absorptive 2D spectrum for a t2 delay of 500 fs measured at an RF power of 0.05. The 2D spectrum has been scaled by a factor of 7.36.

"DP_0,5_T2_500fs_R+NR_fd_scaled_1.38x.txt" contains the absorptive 2D spectrum for a t2 delay of 500 fs measured at an RF power of 0.5. The 2D spectrum has been scaled by a factor of 1.38.

All 2D spectra are plotted against the omega_1 frequency and the omega_3 frequency, which are given as "w1.txt" and "w3.txt", respectively, in units of inverse centimeters.