import numpy as np
from scipy.optimize import root


def andreev_molecule_ic_haxell(phi_1, phi_2, ic_ref, ic_bot, ic_nl):
    """Critical current of an Andreev molecule device with a ref. junction.

    This expression holds when one flux loop applies a phase difference to both of the
    intentional molecule 2-term junctions, while the other only applies a flux to one of
    them.

    Parameters:
    -----------
    phi_1 (float): Flux quanta threading loop 1 in radians, translating to a phase
        difference across the modeled nonlocal Josephson junction.
    phi_2 (float): Flux quanta threading loop 2 in radians, translating
        to a phase difference across junction A.
    ic_ref (float): Critical current of the reference junction in loop 1.
    ic_bot (float): Critical current of the bottom Andreev molecule junction, assumed to
        be the same as that of the top junction.
    ic_nl (float): Critical current of the modeled nonlocal junction.

    Returns:
    --------
    float: Critical current of the full circuit.
    """
    ic = ic_ref + ic_nl * np.cos(phi_1) + ic_bot * np.cos(phi_1 + phi_2)
    return ic


def andreev_molecule_ic_matsuo(phi_1, phi_2, ic_ref, ic_top, ic_nl):
    """Critical current of an Andreev molecule device with a ref. junction.

    This expression holds when each flux loop only phase biases one of the intentional
    molecule 2-term junctions.

    Parameters:
    -----------
    phi_1 (float): Flux quanta threading loop 1 in radians, translating to a phase
        difference across junction A.
    phi_2 (float): Flux quanta threading loop 2 in radians, translating
        to a phase difference across junction B.
    ic_ref (float): Critical current of the reference junction in loop 1.
    ic_top (float): Critical current of the top Andreev molecule junction, assumed to
        be the same as that of the bottom junction.
    ic_nl (float): Critical current of the modeled nonlocal junction.

    Returns:
    --------
    float: Critical current of the full circuit.
    """
    ic = ic_ref + ic_nl * np.cos(phi_1 + phi_2) + ic_top * np.cos(phi_1)
    return ic


def four_term_jj_ic(phi_l, phi_r, ic_ref, ic12, ic13):
    """Critical current of a four-terminal junction centered in two DC SQUID loops.

    Parameters:
    -----------
    phi_l (float): Flux quanta threading SQUID L in radians, translating to a phase
        difference across superconducting terminals 1 and 2 of the four-terminal
        junction.
    phi_r (float): Flux quanta threading the floating SQUID R in radians, translating
        to a phase difference across the superconducting terminals 3 and 4 of the four-
        terminal junction.
    ic_ref (float): Critical current of the reference junction of SQUID L.
    ic12 (float): Critical current (in the two-terminal junction model) of the junction
        formed between terminals 1 and 2 of the four-terminal junction, assumed to be
        the same as that between terminals 3 and 4.
    ic13 (float): Critical current (in the two terminal junction model) of the junction
        formed between terminals 1 and 3, assumed to be the same as that between
        terminals 2 and 4.

    Returns:
    --------
    float: Critical current of the full circuit.
    """

    def phi13_root_fun(pl, pr):
        def func(x):
            phi_sum = pl + pr
            return np.cos(phi_sum) * np.cos(x) - (1 + np.sin(phi_sum)) * np.sin(x)

        return func

    # brute force find all solutions for phi13 between -pi and +pi.
    guesses = np.arange(-np.pi, np.pi, 0.1)
    phi13s = [root(phi13_root_fun(phi_l, phi_r), x0=guess).x[0] for guess in guesses]
    # phi13 determining the critical current should be the one that maximizes current
    # through this branch.
    phi13 = phi13s[np.argmax(np.sin(phi13s))]
    ic = ic_ref + ic12 * np.cos(phi_l) + ic13 * np.sin(phi13)
    return ic
