from pathlib import Path
from qcodes import initialise_or_create_database_at, load_by_id


def load_dataset(run_id: int, db_path: Path):
    """Load individual run from a QCodes database (.db) file."""
    initialise_or_create_database_at(db_path)
    ds = load_by_id(run_id)
    return ds
