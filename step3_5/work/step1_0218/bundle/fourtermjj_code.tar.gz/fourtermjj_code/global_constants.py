from pathlib import Path


class Constants:
    """Constants and parameters that may be used throughout the data repository."""

    BX_TO_BPERP_A = 0.9723  # = cos(theta_x) for device A
    BX_TO_BPERP_B = 0.9894  # = cos(theta_x) for device B

    # Should be colorblind safe
    COLORS = {
        "red": (240 / 255, 30 / 255, 25 / 255),
        "orange": (250 / 255, 118 / 255, 29 / 255),
        "blue": (35 / 255, 146 / 255, 250 / 255),
        "green": (97 / 255, 224 / 255, 83 / 255),
    }
    DPI = 300
    FONT_SIZE = 10
    FONT_SIZE_SMALL = 8
    HALF_WIDTH = 3.375
    VOLT_LEFT_CMAP = "inferno"
    VOLT_RIGHT_CMAP = "magma"
    IC_CMAP = "seismic"

    # Paths:
    AUTOSAVE_PATH = Path("autosaves/")
    DEVA_DB_PATH = Path("data/data_dev_A.db")
    DEVB_DB_PATH = Path("data/data_dev_B.db")
