import numpy as np


def switching_currents(
    array_nd: np.ndarray, currents: np.ndarray, current_axis: int = -1
):
    """Find the index along a current axis of an n-dimensional array of the switching current.

    Parameters:
    -----------
    array_nd (numpy.ndarray): Multidimensional array of data points, where one of its
        axes corresponds to swept bias current.
    currents (numpy.ndarray): Array of applied bias currents.

    Keyword Arguments:
    ------------------
    current_axis (int = -1): Axis index of array_nd corresponding to swept bias current.

    Returns:
    --------
    numpy.ndarray: Array of extracted switching currents with the same shape as array_nd
        but without the current_axis.
    """
    array_nd = np.swapaxes(array_nd, current_axis, -1)
    derivatives = np.abs(np.diff(array_nd, axis=current_axis))
    jump_thresholds = 0.5 * (
        np.min(derivatives, axis=-1) + np.max(derivatives, axis=-1)
    )
    isws = currents[np.argmin(jump_thresholds[..., np.newaxis] - derivatives, axis=-1)]
    array_nd = np.swapaxes(array_nd, current_axis, -1)
    return isws
